library(testthat)
library(xlsx)

test_check("xlsx")
