
## Remove tmp directory if already present
remove_tmp()
