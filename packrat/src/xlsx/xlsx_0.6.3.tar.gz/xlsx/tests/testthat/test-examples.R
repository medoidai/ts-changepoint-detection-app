context('test examples')

test_that('examples succeed', {
  test_examples()
})

