library(testthat)
library(changepoint)

test_check("changepoint")
